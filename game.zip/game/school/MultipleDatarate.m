function [ DatarateMatrix ] = MultipleDatarate( SNRMatrix, Bandwidth )
%MULTIPLEDATARATE Given a signal to noise ratio matrix, and bandwidth,
%calculates the corresponing datarate and returns it.


[rows, cols] = size(SNRMatrix);

% More efficient to preallocate
DatarateMatrix = zeros(rows,cols);
% for each SNR value, calculate the datarate
for row = 1:rows 
    for col = 1:cols
        DatarateMatrix(row, col) = Datarate(SNRMatrix(row,col), Bandwidth);
    end
end

end

