function [ rate ] = Datarate(SNR, Bandwidth) 
% Calculates the datarate at a given distance in M, effect in W and Noise
% in W, bandwidth in Hz and some k. Return the datarate in bits/second.
%



% The  4G standard specifies that if the SNR is less than 0.3, the we don't have
% an signal and the datarate is thus 0
if (SNR < 0.3)
    rate = 0;
else 
    % The maximum datarate is reached when SNR is 63 due to hardware limitations, 
    % even if SNR itself can be higher
    rate = Bandwidth*log2(1 + min(63, SNR));
end