function [ DatarateMatrix ] = CellCoverage( BaseStations, PositionMatrixX, PositionMatrixY, Bandwidth, SignalStrength, Noise, k)
%CELLCOVERAGE Calculates the cellcoverage for each point defined from PositionMatrixX and PositionMatrixY given some values on
% Bandwidth, SignalStrength, Noise, k. Each base station is assumed to have
% the same signal strength, bandwidth, noise and kappa(k). A matrix of
% with datarates in MB/s is returned where each value corresponds to one
% point from the position matrixes.

DistancesToBase = MultipleMinimalDistance(PositionMatrixX, PositionMatrixY, BaseStations);
SignalNoise = MultipleSignalNoise(DistancesToBase, Noise, SignalStrength, k);
% datarate is returned in TB/s, tranforming it to MB
DatarateMatrix = MultipleDatarate(SignalNoise, Bandwidth)/1E6;

end

