close all;
clear;
% maximizes current figure
set(gcf, 'units', 'normalized', 'outerposition', [0 0 1 1]);
%some default values
step=20;
Noise = 10 ^-11.2;
SignalStrength = 1;
k = 4;
Bandwidth = 10E6;
[X, Y] = meshgrid(0:step:2000,0:step:2000);

% The mesh matrixes is of the same size
[rows, cols] = size(X);
BaseStations = [0 0; 2000 2000; 1000, 1000; 2000 0; 0 2000];

DatarateMatrix = CellCoverage(BaseStations, X, Y, Bandwidth, SignalStrength, Noise, k);

surface(X, Y, DatarateMatrix);
zlabel('Datarate (Mb/s)')
xlabel('X - coordinate, units in meter');
ylabel('Y - coordinate, units in meter');

title('Datarate in an area');


Datarates = [0, 10, 20, 30 ,40 ,50 ,60];
[probablities, avg] = Stats(DatarateMatrix, Datarates);
figure
bar(Datarates, probablities);

ylabel('Probability');
xlabel('Datarate (Mb/s)');
titleString = sprintf('Probability to have a certain datarate. Avarage %0.2f Mb/s', avg);
title(titleString);