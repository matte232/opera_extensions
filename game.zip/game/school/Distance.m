function [ res ] = Distance( point1, point2 )
%DISTANCE Calculates the Euclidean distance between to points in the same 2D coordinate
% system

res = sqrt(sum((point2 - point1).^2) );
end

