function [ ratio ] = SignalNoiseRatio( Noise, SignalStrength, Distance, k )
%SIGNALNOISERATIO Given the square Noise in W, SignalStrenth in W, Distance in m and some k, 
% Calculates the signal to noise ratio. Returning the ratio
%   
ratio = EffectAtDistance(SignalStrength, Distance, k)/Noise;

end

