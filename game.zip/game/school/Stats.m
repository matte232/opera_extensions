function [ ResVector, avg ] = Stats( Matrix, steps )
%STATS Calulates the probability of min to max values

[rows, cols] = size(Matrix);

[~, noSteps] = size(steps);
ResVector = zeros(1,noSteps);

sum = 0;

for row = 1:rows
    for col = 1:cols
        for index = 1:noSteps
            if steps(index) >= Matrix(row,col)
                %adding too many here, will not take into the calculation
                %that the same value is added multiple times, adjust for it
                %later
                ResVector(index) = ResVector(index) +1;
            end
        end
        sum = sum + Matrix(row,col);
    end
end

%Adjust for overadding
prev = 0;
for index = noSteps:-1:2
    ResVector(index) = ResVector(index) - ResVector(index-1);
end

%Now we have the number of items in each category
ResVector = ResVector./(cols*rows);


avg = sum/(row*col);

end

