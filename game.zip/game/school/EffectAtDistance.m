function [ res ] = EffectAtDistance( InEffect, Distance, k )
%EFFECTATDISTANCE Calculates the effective effect at a distance Distance
% meters from the current position given an in effect, distance and some k.

res = InEffect/(1 + Distance)^k;

end

