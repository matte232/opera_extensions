function [ SignalNoiseMatrix ] = MultipleSignalNoise( DistanceMatrix, Noise, SignalStrength, k )
%MULTIPLESIGNALNOISE Given a distance matrix, noise, signalstrength and k
%calculates a matrix with signal to noise ratio for every distance
[rows, cols] = size(DistanceMatrix);

% More efficient to preallocate
SignalNoiseMatrix = zeros(rows,cols);
% Calculates the SNR value for each distance in the given matrix
for row = 1:rows 
    for col = 1:cols
        SignalNoiseMatrix(row, col) = SignalNoiseRatio(Noise, SignalStrength, DistanceMatrix(row,col), k);
    end
end

end

