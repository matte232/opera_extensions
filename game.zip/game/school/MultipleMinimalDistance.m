function [ DistanceMatrix ] = MultipleMinimalDistance( MeshMatrixX, MeshMatrixY, origo )
%MULTIPLEDISTANCE Calculates the minimal distance between many points built from 2 
% equal sized matrixes and a list of origos, returns a matrix with the distances


[rows, cols] = size(MeshMatrixX);

% More efficient to preallocate
DistanceMatrix = zeros(rows,cols);
%For each point, calculate the minimal distance to some origo
for row = 1:rows 
    for col = 1:cols
        % Minimal distance from mesh(row,col) to some origo
        DistanceMatrix(row, col) = MinimalDistance(MeshMatrixX(row, col), MeshMatrixY(row,col), origo);
    end
end

end
% Calculates the minimal distance to a target from a list och targets from a origin x y 
function [min] = MinimalDistance(x, y, targets)

min = intmax('int64');
[rows, ~] = size(targets);
for row = 1:rows
    d = Distance([x y], targets(row, :));
    if d < min
        min = d;
    end
end

end