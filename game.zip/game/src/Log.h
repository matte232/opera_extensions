#pragma once
#include <iostream>
class Log 
{
public:
	Log(bool enable) : enabled(enable) { }
	std::ostream& operator<<(const std::string&) const;
	std::ostream& operator<<(const int&) const;
	std::ostream& operator<<(const float&) const;
	std::ostream& operator<<(const double&) const;

	bool loggingEnabled() const {
		return enabled;
	}

	bool& loggingEnabled(bool enable) {
		return enabled = enable;
	}

	~Log();
private:
	bool enabled;
};

static Log logger{ true };

