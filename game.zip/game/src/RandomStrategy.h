#pragma once
#include "unit.h"
#include <array>
#include "MoveStrategy.h"
#include "PlayState.h"

class RandomStrategy : public MoveStrategy {

 public:
   RandomStrategy(const GameArray& m ) : MoveStrategy(m) {}
   virtual void Move() override;

};
