
#include <SDL2/SDL.h>
#include "Cleanup.h"
template<typename T>
class SDL_Object {

public:
   SDL_Object() = default;
   SDL_Object(T* o) : obj(o) {}
   ~SDL_Object() {Cleanup(obj);}
   SDL_Object& operator=(const SDL_Object&) = delete;
   SDL_Object(const SDL_Object&) = delete;

   SDL_Object(SDL_Object&& o){obj = o.obj; o.obj = nullptr;} 
   SDL_Object& operator=(SDL_Object&& o) & {obj = o.obj; o.obj = nullptr; return *this;}
   SDL_Object& operator=(T* o)& {if(o != obj) {Cleanup(obj); obj = o; } return *this;}

   bool operator==(nullptr_t) const {return obj == nullptr;}
   bool operator!=(nullptr_t) const {return obj != nullptr;}
   operator bool() const {return obj != nullptr;}
   operator T*() const  {return obj;}
   
   T& operator*() {
      return *obj;
   }

   T* operator->() {
      return obj;
   }

   T* get(){return obj;}
private:
   T* obj;
};


using Renderer = SDL_Object<SDL_Renderer>;
