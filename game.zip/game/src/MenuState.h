#pragma once
#include "GameState.h"

class MenuState : public GameState {
public:
   MenuState() = default;
   virtual ~MenuState() = default;
   bool Paint(SDL_Renderer*) override;
      virtual void UpdateAndPaint(SDL_Renderer*, const TimeObject& t, unsigned screenPosX, unsigned screenPosY) override;
   
};

