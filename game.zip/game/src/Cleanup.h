/*Made for easy cleanup at exceptions, original code taken from http://www.willusher.io/sdl2%20tutorials/2014/08/01/postscript-1-easy-cleanup/
*/
#ifndef CLEANUP_H 
#define CLEANUP_H
#include <utility>
#include <SDL2/SDL.h>

template<typename T, typename... Args>
void Cleanup(T *t, Args&&... args)
{
	//clean up first argument
	Cleanup(t);
	//goes through the rest of the arguments
	Cleanup(std::forward<Args>(args)...);
}
template<>
void Cleanup<SDL_Window>(SDL_Window* win);
template<>
void Cleanup<SDL_Renderer>(SDL_Renderer* ren);
template<>
void Cleanup<SDL_Texture>(SDL_Texture* tex);
template<>
void Cleanup<SDL_Rect>(SDL_Rect* rect);
template<>
void Cleanup<SDL_Surface>(SDL_Surface* surf);

//Instantiate, will make it work like a standard h-file
template void Cleanup<SDL_Texture>(SDL_Texture* tex);
template void Cleanup<SDL_Window>(SDL_Window* tex);
template void Cleanup<SDL_Renderer>(SDL_Renderer* tex);
template void Cleanup<SDL_Rect>(SDL_Rect* tex);
template void Cleanup<SDL_Surface>(SDL_Surface* tex);

#endif
