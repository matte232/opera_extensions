#pragma once
#include <SDL2/SDL.h>
#include <chrono>
#include "Screen.h"
#include "SDL_Object.h"

class GameState;
class GameEngine
{
public:
   GameEngine();
   ~GameEngine();

   void mainLoop();
   void update();
   void clear();
   static GameState* state;


   SDL_Renderer* getRenderer() {SDL_Renderer* r{renderer};return r;}
   

private:
   Screen screen{ "AoE" };   
//   Renderer renderer;
   SDL_Renderer* renderer{nullptr};
   long unsigned frame_counter{ 0 };

};

