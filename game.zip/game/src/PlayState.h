#pragma once
#include <vector>
#include <array>
#include "GameState.h"
#include "unit.h"

const static int gridSizeX{500};
const static int gridSizeY{200};
using GameArray = std::array<std::array<bool, gridSizeX>, gridSizeY>;

class PlayState :
   public GameState
{
public:
   PlayState();
   ~PlayState();
   void UpdateAndPaint(SDL_Renderer* r, TimeObject& t, unsigned screenPosX, unsigned screenPosY) override;
 
private:
   
   
 
   std::vector<Obj> obstacles;
   GameArray grid;
   std::vector<Obj> players;

   void GenerateMap();

   const int gridSize{gridSizeX*gridSizeY};
   const int no_players{20000};
};

