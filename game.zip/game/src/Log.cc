#include "Log.h"
#include <iostream>
#include <string>

using namespace std;

std::ostream& Log::operator<<(const std::string& obj) const {
	if (loggingEnabled()) {
		return cout << obj;

	}
	return cout << obj;
}
std::ostream& Log::operator<<(const int& obj) const{
	if (loggingEnabled()) {
		return cout << obj;

	}
	return cout << obj;
}
std::ostream& Log::operator<<(const float& obj) const{
	if (loggingEnabled()) {
		return cout << obj;

	}
	return cout << obj;
}
std::ostream& Log::operator<<(const double& obj) const{
	if (loggingEnabled()) {
		return cout << obj;

	}
	return cout << obj;
}

Log::~Log()
{}