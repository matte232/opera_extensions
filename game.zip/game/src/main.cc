/*This source code copyrighted by Lazy Foo' Productions (2004-2013)
and may not be redistributed without written permission.*/

//Using SDL and standard IO
#include <SDL2/SDL.h>
#include "Log.h"
#include <memory>
#include "GameEngine.h"
//Screen dimension constants
using namespace std;
int main()
{

	//Initialize SDL
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
           SDL_Log("SDL could not initialize! SDL_Error: %s", SDL_GetError());
           return 1;
	}

	GameEngine* engine = new GameEngine;
	engine->mainLoop();
	SDL_Quit();

	return 0;
}
