#include "unit.h"
#include "GameEngine.h"

void unit::Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) {

}

void unit::paint(SDL_Renderer* r) {
  rect = SDL_Rect{x, y, 10, 10};

 
 
  SDL_RenderDrawRect(r, &rect);
}

