#include "Object.h"
#include "GameEngine.h"


int Object::getX() const {
   return x;
}
int Object::getY() const {
   return y;
}


int Object::getGridX() const {
   return gridX;
}

int Object::getGridY() const {
   return gridY;
}

void Object::setGridPos(unsigned x, unsigned y) {
  gridX = x;
  gridY = y;

  this->x = gridX*10;
  this->y = gridY*10;
}

void Object::align(unsigned screenPosX, unsigned screenPosY) {
   x -= screenPosX;
   y -= screenPosY;
}

UnmovableObject::UnmovableObject(const SDL_Rect& r) {
   rect = r;
}

void UnmovableObject::paint(SDL_Renderer* r) {
//  rect = SDL_Rect{x, y, 10, 10};
   
   
   SDL_RenderDrawRect(r, &rect);
}

void UnmovableObject::Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) {
   setGridPos(gridX, gridY);
   align(screenPosX, screenPosY);
   // SDL_Log("%d %d", rect.x, x// );
   rect.x = x;
   rect.y = y;
}



using namespace std::chrono;
using tp = high_resolution_clock::time_point;

TimeObject::TimeObject() : current(high_resolution_clock::now()), previous(high_resolution_clock::duration::zero()), start(high_resolution_clock::now()) {
   
}

unsigned long TimeObject::getDiff() {
   return duration_cast<milliseconds>(current - previous).count();
}

unsigned long TimeObject::getElapsed() {
   return duration_cast<milliseconds>(current - start).count();

}


void TimeObject::tick() {
   previous = current;
   current = high_resolution_clock::now();
}

void TimeObject::restart() {
   start = current = high_resolution_clock::now();
   previous = high_resolution_clock::time_point{high_resolution_clock::duration::zero()};
}
