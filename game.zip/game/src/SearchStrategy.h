#pragma once
#include "unit.h"
#include <array>
#include "MoveStrategy.h"

class SearchStrategy : public MoveStrategy {

 public:
 SearchStrategy(const GameArray& m ) : MoveStrategy(m) {}
  virtual void Move() override;

};
