#pragma once
#include "Object.h"
#include "GameEngine.h"
class GameState
{
public:
   GameState() = default;
   
   virtual ~GameState();
   virtual void UpdateAndPaint(SDL_Renderer*, TimeObject& t, unsigned screenPosX, unsigned screenPosY) = 0;
  

private:
};

