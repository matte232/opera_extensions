#pragma once
#include <SDL2/SDL.h>
#include <string>
class Screen
{
public:
	Screen() = delete;
	Screen(const std::string& title); 

	~Screen();
	static SDL_Window* getWindow() ;


	static int width, heigth;
private:
	static SDL_Window* window;
	
};

