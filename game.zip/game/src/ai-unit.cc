#include "ai-unit.h"


void aiUnit::setMoveStrategy(MoveStrategy* strategy) {
  this->strategy = strategy;
}

void aiUnit::Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) {
  strategy->Move();
  align(screenPosX, screenPosY);
}
