#include "MoveStrategy.h"
#include <random>

using namespace std;


void MoveStrategy::setUnit(unit* const p) {
  player = p;
}
