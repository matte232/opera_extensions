#include "PlayState.h"
#include "GameEngine.h"
#include "ai-unit.h"
#include <array>
#include <random>
#include <SDL2/SDL.h>
#include "RandomStrategy.h"
#include <future>
#include "semaphore.h"
#include <thread>
#include <mutex>
#include <condition_variable>
using namespace std;
struct param{
   SDL_Renderer* r;
   std::vector<Obj>* vec;
   TimeObject* t;
   unsigned screenPosX;
   unsigned screenPosY;
};
semaphore draw_call, worker_done;
param data;


int worker(void *d) {
   param *data = (param*)d;
   while(true) {
      draw_call.wait();
      for(auto& obj : *data->vec) {
         obj->Update(*(data->t), data->screenPosX, data->screenPosY);    
          
      }
      worker_done.notify();
   }
   return 0;
}

PlayState::PlayState()
{
   //SDL_Thread* t =  SDL_CreateThread(worker, "WorkerThread", (void *)&data);
   // thread *t = new thread(worker, &data);
   GenerateMap();
   for(int i = 0; i < no_players; ++i) {
      players.push_back(Movable(new aiUnit{new RandomStrategy{grid}}));
   }
}


PlayState::~PlayState()
{
   


}



void PlayState::UpdateAndPaint(SDL_Renderer* r, TimeObject& t, unsigned screenPosX, unsigned screenPosY) {
   // param par{r, &obstacles, &t, screenPosX, screenPosY};
   // data = par;
   //draw_call.notify();
   //worker_done.wait();
   
   SDL_SetRenderDrawColor(r, 0, 0, 0, 255);
   
   for(auto& obj : obstacles) {
      obj->Update(t, screenPosX, screenPosY);
      obj->paint(r);
   }
   
   SDL_SetRenderDrawColor(r, 0, 0, 255, 255);	
   for(auto& player : players) {
      player->Update(t, screenPosX, screenPosY);
      player->paint(r);
   }
}


void PlayState::GenerateMap() {
   random_device random;
   for (int x = 0; x < gridSizeX; ++x) {
      for(int y = 0; y < gridSizeY; ++y) {
         if(random() % 5 == 0 ) {
            UnMovable obj = UnMovable(new UnmovableObject{SDL_Rect{x*10, y*10, 10u,10u}});
            obj->setGridPos(x,y);
            obstacles.push_back(obj);
            grid.at(y).at(x) = true;
         } else {
            grid.at(y).at(x) = false;
         }
      }


   }
}
