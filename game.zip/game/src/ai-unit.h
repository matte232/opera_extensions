#pragma once
#include "MoveStrategy.h"
#include "unit.h"

class aiUnit : public unit {
public:
   aiUnit() : strategy(nullptr){};
   aiUnit(MoveStrategy* strategy) : strategy(strategy) {strategy->setUnit(this);}
   ~aiUnit() { delete strategy;}
   void setMoveStrategy(MoveStrategy* strategy);
   virtual void Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) override;
  
private:
   MoveStrategy* strategy;
};
