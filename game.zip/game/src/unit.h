#pragma once
#include <SDL2/SDL.h>
#include "Object.h"
class unit : public MovableObject {
 public:
   virtual void Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY);
   virtual void paint(SDL_Renderer*) override;
   virtual ~unit() = default;


 

};
