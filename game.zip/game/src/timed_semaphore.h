#include <mutex>
#include <condition_variable>
#include <chrono>
using namespace std;
using namespace std::chrono;


class tmutex : public mutex {
public:
   tmutex() : mutex(){}
   void try_lock_until(const std::chrono::milliseconds& tp) {
      stop = tp + std::chrono::high_resolution_clock::now();
      while(std::chrono::high_resolution_clock::now() < stop) {
         if(try_lock()){
            SDL_Log("got_lock");
            return;
         }
      }
      lock();
            SDL_Log("got_lock");
   }
private:
   std::chrono::high_resolution_clock::time_point stop;
};
   
class semaphore{
private:
   tmutex mtx;
   condition_variable cv;
   int count;

public:
   semaphore(int count_ = 0):count(count_){}

   void notify()
      {
         unique_lock<mutex> lck(mtx, defer_lock_t{});
         mtx.try_lock_until((milliseconds)30);
         ++count;
         cv.notify_one();
      }
   void wait()
      {
         unique_lock<mutex> lck(mtx, defer_lock_t{});
         mtx.try_lock_until((milliseconds)30);

         while(count == 0){
            cv.wait(lck);
         }
         count--;
      }
};
