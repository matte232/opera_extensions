#include "Screen.h"
#include <stdexcept>
using namespace std;
int Screen::width{ 0 };
int Screen::heigth{ 0 };
SDL_Window* Screen::window{nullptr};
Screen::Screen(const string& title)
{
	SDL_Rect r;
	if (SDL_GetDisplayBounds(0, &r) != 0) {
		SDL_Log("SDL_GetDisplayBounds failed: %s", SDL_GetError());
		throw runtime_error("SDL_GetDisplayBounds failed");
	}
	width = r.w;
	heigth = r.h;
	window = SDL_CreateWindow(title.c_str(), SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, r.w, r.h, SDL_WINDOW_SHOWN|SDL_WINDOW_FULLSCREEN|SDL_WINDOW_BORDERLESS);
	if (window == nullptr)
	{
		SDL_Log( "Window could not be created! SDL_Error: %s\n", SDL_GetError());
		throw runtime_error("Window could not be created!");
	}
	
}


Screen::~Screen()
{
	SDL_DestroyWindow(window);
}

SDL_Window* Screen::getWindow()  {
	return window;
}
