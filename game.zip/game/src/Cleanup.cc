#include "Cleanup.h"
#include <utility>
#include <SDL2/SDL.h>

//ugly hack so we don't try to delete something on the stack
//static variables are still at danger, but ok for this project
template<typename T>
bool isStackAllocated(T* obj) { 
   int i;
   if(reinterpret_cast<void*>(obj) >= reinterpret_cast<void*>(&i)) {
      return true;
   }
   return false;
}

template<>
void Cleanup<SDL_Window>(SDL_Window* win)
{
   SDL_Log("destroying window");
   if (!win or isStackAllocated(win))
      return;
   SDL_DestroyWindow(win);
}
template<>
void Cleanup<SDL_Renderer>(SDL_Renderer* ren)
{
   SDL_Log("destroying renderer");
   if (!ren or isStackAllocated(ren))
      return;
   SDL_DestroyRenderer(ren);
}
template<>
void Cleanup<SDL_Texture>(SDL_Texture* tex)
{
   if(!tex or isStackAllocated(tex))
      return;
   SDL_DestroyTexture(tex);
}
template<>
void Cleanup<SDL_Surface>(SDL_Surface* surf)
{
   if (!surf or isStackAllocated(surf))
      return;
   SDL_FreeSurface(surf);
}
template<>
void Cleanup<SDL_Rect>(SDL_Rect* rect)
{
   if (!rect or isStackAllocated(rect))
      return;

   delete rect;
}
