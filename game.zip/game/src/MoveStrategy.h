#pragma once
#include "unit.h"
#include <array>
#include "PlayState.h"


class MoveStrategy {

 public:
   MoveStrategy(const GameArray& m ) : player(nullptr), model(m) {}
  virtual void Move() = 0;
  virtual void setUnit(unit* const  p);
  virtual ~MoveStrategy() = default;

 protected:
  unit* player;
  GameArray model;
};
