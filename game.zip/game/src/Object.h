#pragma once
#include <SDL2/SDL.h>
#include <memory>
#include <chrono>

class TimeObject {
public:
   TimeObject();
   unsigned long getElapsed();
   unsigned long getDiff();
   void tick();
   void restart();
private:
   std::chrono::high_resolution_clock::time_point current, previous, start;
   
};


class Object {
public:
   Object() = default;
   virtual ~Object() = default;

   virtual void paint(SDL_Renderer*) = 0;
   virtual void Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) = 0;
   virtual int getX() const;
   virtual int getY() const;
   virtual int getGridX() const;
   virtual int getGridY() const;
   virtual void setGridPos(unsigned x, unsigned y);

protected:
   int x{0};
   int y{0};

   virtual void align(unsigned screenPosX, unsigned screenPosY);
   unsigned gridX{250}, gridY{100};
   SDL_Rect rect;
};



class MovableObject : public Object {
public:

};

class UnmovableObject : public Object {
public:
   UnmovableObject(const SDL_Rect&);
   virtual void Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY);
   void paint(SDL_Renderer*);
};

using UnMovable = std::shared_ptr<UnmovableObject>;
using Movable = std::shared_ptr<MovableObject>;
using Obj = std::shared_ptr<Object>;

