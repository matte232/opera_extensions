#include "MenuState.h"
#include <iostream>

using namespace std;
bool MenuState::Paint(SDL_Renderer*) {
  
  return true;
} 

void MenuState::Update(const TimeObject& t, unsigned screenPosX, unsigned screenPosY) {

}
