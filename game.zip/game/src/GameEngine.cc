#include "GameEngine.h"
#include "PlayState.h"
#include <array>
#include <chrono>
#include <ratio>

using namespace std;
using namespace std::chrono;

GameState * GameEngine::state;

GameEngine::GameEngine()
{	
   if(renderer == nullptr)
      renderer = SDL_CreateRenderer(screen.getWindow(), -1, SDL_RENDERER_ACCELERATED);
   
   if (renderer == nullptr) {
      SDL_Log("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
      throw runtime_error("Renderer could not be created!");
   }
   SDL_Rect r;
   if (SDL_GetDisplayBounds(0, &r) != 0) {
      SDL_Log("SDL_GetDisplayBounds failed: %s", SDL_GetError());
      throw runtime_error("SDL_GetDisplayBounds failed");
   }
   SDL_RenderSetLogicalSize(renderer, r.w, r.h);
   
   if(state == nullptr)
      state = new PlayState;
}


GameEngine::~GameEngine()
{
   //can't do anything since the renderer is shared between all objects
   SDL_Log("Shutting down game engine");
}

void GameEngine::mainLoop() {
   bool run{true};
   TimeObject t;
   int screenX{0}, screenY{0};
   float scaleX{1}, scaleY{1};
   while (run) {
      SDL_Event e;
      if (SDL_PollEvent(&e)) {
         if (e.type == SDL_QUIT) {
            break;
         }
         else if (e.type == SDL_MOUSEBUTTONDOWN) {
            break;
         } else if (e.type == SDL_MOUSEBUTTONUP) {
            break;
         }  else if(e.type == SDL_KEYDOWN) {
            switch( e.key.keysym.sym )
            {
            case SDLK_UP:
               
               screenY -= 10;
               break;

            case SDLK_DOWN:

               screenY += 10;
               break;

            case SDLK_LEFT:
               screenX -= 10;
               break;

            case SDLK_RIGHT:
               screenX += 10;
               break;
            case SDLK_m:
               scaleX *= 0.5;
               scaleY *= 0.5;
               
               SDL_RenderSetScale(renderer, scaleX, scaleY);
               break;
            case SDLK_n:
               scaleX *= 2;
               scaleY *= 2;
               
               SDL_RenderSetScale(renderer, scaleX, scaleY);
               break;
            case SDLK_b:
               scaleX = 1;
               scaleY = 1;
               SDL_RenderSetScale(renderer, scaleX, scaleY);
               
            default:
               break;
            }
         }
      }
      
      if (t.getElapsed() > 1000) {
         t.restart();
         SDL_Log("Current FPS: %lu", frame_counter);
         frame_counter = 0;
      }

      clear();
      state->UpdateAndPaint(renderer, t, screenX, screenY);
        
      update();
      frame_counter++;

      t.tick();

   }
}

void GameEngine::update() {
   SDL_RenderPresent(renderer);

}

void GameEngine::clear() {
   SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
   // Clear the entire screen to our selected color.
   SDL_RenderClear(renderer);
}
