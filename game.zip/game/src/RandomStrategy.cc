#include "RandomStrategy.h"
#include <random>

using namespace std;
void RandomStrategy::Move() {
  random_device rd;
  bool canNotMove = true;
  int x;
  int y;
  do{
     x = player-> getGridX() + ((rd() % 3) -1);
     y = player-> getGridY() + ((rd() % 3) -1);
    if (x < 0 or y < 0 or x >= gridSizeX or y >= gridSizeY) 
      canNotMove = true;
    else 
      canNotMove = model.at(y).at(x);
  }while(canNotMove);
  player->setGridPos(x,y);

}
